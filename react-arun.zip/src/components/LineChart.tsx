import React, { Component, useState, useEffect } from 'react';
import logo from './logo.svg';
import axios from 'axios';
import Chart from 'react-apexcharts';

const App = () => {
  const [category, setCategory] = useState([]);
  const [data, setData] = useState([
    {
      name: 'High - 2013',
      data: [28, 29, 33, 36, 32, 32, 33],
    },
    {
      name: 'Low - 2013',
      data: [12, 11, 14, 18, 17, 13, 13],
    },
  ]);

  // useEffect(() => {
  //   const age: any = [];
  //   const salary: any = [];

  //   axios
  //     .get('https://dummy.restapiexample.com/api/v1/employees')
  //     .then(response => {
  //       console.log('response', response);
  //       response.data.data.map((item: any) => {
  //         console.log('item', item);
  //         age.push(item.employee_age);
  //         salary.push(item.employee_salary);
  //       });
  //       setCategory(salary);
  //       setData(age);
  //       // setObject({
  //       //   chart: {
  //       //     id: 'apexchart-example'
  //       //   },
  //       //   xaxis: {
  //       //     categories: salary
  //       //   }
  //       // })
  //       // setSeries([{
  //       //   name: 'series-1',
  //       //   data: age
  //       // }])
  //       console.log('age', age, salary);
  //     })
  //     .catch(e => {
  //       alert(e);
  //     });
  // }, []);

  return (
    <Chart
      options={{
        title: {
          text: 'Bot Overview',
          align: 'center',
        },
        xaxis: {
          categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
          title: {
            text: 'Month',
          },
        },
        yaxis: {
          title: {
            text: 'Cost Per Feature(K)',
          },
          min: 0,
          max: 600,
        },
        dataLabels: {
          enabled: true,
        },
        chart: {
          height: 350,
          type: 'line',
          dropShadow: {
            enabled: true,
            color: '#000',
            top: 18,
            left: 7,
            blur: 10,
            opacity: 0.2,
          },
        },
        legend: {
          position: 'top',
          horizontalAlign: 'left',
          floating: true,
          offsetY: -25,
          offsetX: -5,
        },
      }}
      series={[
        {
          name: 'Vectrous',
          data: [328, 329, 33, 36, 32, 372, 33],
        },
        {
          name: 'USA',
          data: [300, 125, 133, 188, 199, 500, 513],
        },
        {
          name: 'FRANCE',
          data: [112, 111, 114, 18, 17, 153, 13],
        },
        {
          name: 'ITALY',
          data: [22, 114, 514, 418, 517, 123, 183],
        },
        {
          name: 'CLASP',
          data: [123, 180, 154, 189, 171, 513, 133],
        },
      ]}
      type='line'
      width={'100%'}
      height={350}
    />
  );
};

export default App;
