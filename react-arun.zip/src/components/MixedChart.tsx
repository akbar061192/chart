import React, { Component, useState, useEffect } from 'react';
import logo from './logo.svg';
import axios from 'axios';
import Chart from 'react-apexcharts';

const App = () => {
  const [category, setCategory] = useState([]);
  const [data, setData] = useState([
    {
      name: 'High - 2013',
      data: [28, 29, 33, 36, 32, 32, 33],
    },
    {
      name: 'Low - 2013',
      data: [12, 11, 14, 18, 17, 13, 13],
    },
  ]);

  // useEffect(() => {
  //   const age: any = [];
  //   const salary: any = [];

  //   axios
  //     .get('https://dummy.restapiexample.com/api/v1/employees')
  //     .then(response => {
  //       console.log('response', response);
  //       response.data.data.map((item: any) => {
  //         console.log('item', item);
  //         age.push(item.employee_age);
  //         salary.push(item.employee_salary);
  //       });
  //       setCategory(salary);
  //       setData(age);
  //       // setObject({
  //       //   chart: {
  //       //     id: 'apexchart-example'
  //       //   },
  //       //   xaxis: {
  //       //     categories: salary
  //       //   }
  //       // })
  //       // setSeries([{
  //       //   name: 'series-1',
  //       //   data: age
  //       // }])
  //       console.log('age', age, salary);
  //     })
  //     .catch(e => {
  //       alert(e);
  //     });
  // }, []);

  return (
    <Chart
      options={{
        title: {
          text: 'Total QA Usage',
          align: 'center',
        },
        chart: {
          height: 350,
          type: 'line',
        },
        stroke: {
          width: [0, 4],
        },
        dataLabels: {
          enabled: true,
          enabledOnSeries: [1],
        },
        labels: [
          '01 Jan 2001',
          '02 Jan 2001',
          '03 Jan 2001',
          '04 Jan 2001',
          '05 Jan 2001',
          '06 Jan 2001',
          '07 Jan 2001',
          '08 Jan 2001',
          '09 Jan 2001',
          '10 Jan 2001',
          '11 Jan 2001',
          '12 Jan 2001',
        ],
        xaxis: {
          type: 'datetime',
        },
        yaxis: [
          {
            title: {
              text: 'Website Blog',
            },
          },
          {
            opposite: true,
            title: {
              text: 'Social Media',
            },
          },
        ],
        legend: {
          position: 'top',
          horizontalAlign: 'left',
          floating: true,
          offsetY: -25,
          offsetX: -5,
        },
      }}
      series={[
        {
          name: 'Website Blog',
          type: 'column',
          data: [440, 505, 414, 671, 227, 413, 201, 352, 752, 320, 257, 160],
        },
        {
          name: 'Social Media',
          type: 'line',
          data: [23, 42, 35, 27, 43, 22, 17, 31, 22, 22, 12, 16],
        },
      ]}
      width={'100%'}
      type='line'
      height={350}
    />
  );
};

export default App;
