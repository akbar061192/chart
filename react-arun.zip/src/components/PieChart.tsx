import React, { Component, useState, useEffect } from 'react';
import logo from './logo.svg';
import axios from 'axios';
import Chart from 'react-apexcharts';

const App = () => {
  const [category, setCategory] = useState([]);
  const [data, setData] = useState([
    {
      name: 'High - 2013',
      data: [28, 29, 33, 36, 32, 32, 33],
    },
    {
      name: 'Low - 2013',
      data: [12, 11, 14, 18, 17, 13, 13],
    },
  ]);

  // useEffect(() => {
  //   const age: any = [];
  //   const salary: any = [];

  //   axios
  //     .get('https://dummy.restapiexample.com/api/v1/employees')
  //     .then(response => {
  //       console.log('response', response);
  //       response.data.data.map((item: any) => {
  //         console.log('item', item);
  //         age.push(item.employee_age);
  //         salary.push(item.employee_salary);
  //       });
  //       setCategory(salary);
  //       setData(age);
  //       // setObject({
  //       //   chart: {
  //       //     id: 'apexchart-example'
  //       //   },
  //       //   xaxis: {
  //       //     categories: salary
  //       //   }
  //       // })
  //       // setSeries([{
  //       //   name: 'series-1',
  //       //   data: age
  //       // }])
  //       console.log('age', age, salary);
  //     })
  //     .catch(e => {
  //       alert(e);
  //     });
  // }, []);

  return (
    <Chart
      options={{
        title: {
          text: 'Feedback',
          align: 'center',
        },
        chart: {
          width: 380,
          type: 'pie',
        },
        labels: ['Neutral', 'Negative', 'Positive'],
        responsive: [
          {
            breakpoint: 480,
            options: {
              chart: {
                width: 200,
              },
              legend: {
                position: 'bottom',
              },
            },
          },
        ],
      }}
      series={[44, 35, 48]}
      type='pie'
      width={'100%'}
      height={350}
    />
  );
};

export default App;
