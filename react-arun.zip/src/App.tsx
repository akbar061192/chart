import SideDrawer from './components/SideDrawer'

const App = () => {
  return (
    <>
    <SideDrawer />
    </>
  )
}

export default App